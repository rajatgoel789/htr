from extract_dictionary import extract_dictionary_from_para
from  tesseract_ocr import image_to_text

def get_info(imPath):
    return extract_dictionary_from_para(image_to_text(imPath,psm=3))



if __name__== "__main__":
    imPath = "/Users/gopalmali/Projects_Office/BitBucket/linehtr/HTR/data/MS_sample_forms/sf8.png"
    info_dict = get_info(imPath)

    for k, v in info_dict.items():
        print(k, " : ", v)
