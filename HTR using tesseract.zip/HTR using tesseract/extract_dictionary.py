import re


# call --->extract_dictionary_from_para(ANY_STRING)

def find_branch(full_nos):
    branch = []
    for i in range(0,3):
        branch.append(full_nos[i])
    return " ".join(branch)


def find_account(full_nos):
    account = []
    for i in range(3,9):
        account.append(full_nos[i])
    return " ".join(account)


def count_occurences(s, word):
    # helps to find the indexes of the words
    count = 0
    st = []
    end = []
    for i in range(len(s)):
        if s[i:i+len(word)] == word:
            count += 1
            st.append(i)
            end.append(i+len(word))
    return count, st, end


def find_user_name(para):
    # returns all the usernames
    my_word = "Beneficiary's Full Name"
    count, start, end = count_occurences(para, my_word)
    name = []
    address_index = para.index('Address')

    number_of_loops = count - 1
    for i in range(0,number_of_loops):
        n = i + 1
        print(i)

        name.append(para[end[i]:start[n]])
    name.append(para[end[-1]:address_index])

    return name


def find_addresses(para):
    # all the addresses will be extracted and returned in form of list
    my_word = "Address"
    count, start, end = count_occurences(para, my_word)
    user_addresses = []
    number_of_loops = count - 1
    for i in range(0,number_of_loops):
        n = i + 1
        print(i)

        user_addresses.append(para[end[i]:start[n]])
    user_addresses.append(para[end[-1]:len(para)])
    # print('process done')

    return user_addresses


def extract_dictionary_from_para(para):
    dictionary_form = {}
    all_nos = re.findall('\d+', para)
    joined = " ".join(all_nos)
    full_nos = []
    for i in joined:
        if i != ' ':
            full_nos.append(i)

    para = para.replace("\n", "")
    dictionary_form['branch_number'] = find_branch(full_nos)
    dictionary_form['account_number'] = find_account(full_nos)
    dictionary_form['names'] = find_user_name(para)
    dictionary_form['addresses'] = find_addresses(para)
    return dictionary_form


